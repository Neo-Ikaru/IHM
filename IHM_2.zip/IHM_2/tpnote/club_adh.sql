﻿/*
MySQL Backup
Source Server Version: 5.5.37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
--  Table structure for `ADHERENT`
-- ----------------------------
DROP TABLE IF EXISTS `ADHERENT`;
CREATE TABLE `ADHERENT` (
  `adh_num` int(11) NOT NULL AUTO_INCREMENT,
  `adh_nom` varchar(20) NOT NULL,
  `adh_prenom` varchar(20) NOT NULL,
  `adh_adr` varchar(50) DEFAULT NULL,
  `adh_cp` varchar(5) DEFAULT NULL,
  `adh_ville` varchar(30) DEFAULT NULL,
  `adh_mel` varchar(50) NOT NULL,
  `adh_civ` varchar(3) NOT NULL,
  `csp_num` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`adh_num`),
  KEY `fk_csp_num_idx` (`csp_num`),
  CONSTRAINT `fk_csp_num` FOREIGN KEY (`csp_num`) REFERENCES `CSP` (`csp_num`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- ----------------------------
--  Table structure for `ADHESION`
-- ----------------------------
DROP TABLE IF EXISTS `ADHESION`;
CREATE TABLE `ADHESION` (
  `adh_num` int(11) NOT NULL,
  `theme_num` int(11) NOT NULL,
  PRIMARY KEY (`adh_num`,`theme_num`),
  KEY `fk_adh_num_idx` (`adh_num`),
  KEY `fk_theme_num_idx` (`theme_num`),
  CONSTRAINT `fk_theme_num` FOREIGN KEY (`theme_num`) REFERENCES `THEME` (`theme_num`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_adh_num` FOREIGN KEY (`adh_num`) REFERENCES `ADHERENT` (`adh_num`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
--  Table structure for `CSP`
-- ----------------------------
DROP TABLE IF EXISTS `CSP`;
CREATE TABLE `CSP` (
  `csp_num` varchar(5) NOT NULL,
  `csp_lib` varchar(100) NOT NULL,
  PRIMARY KEY (`csp_num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
--  Table structure for `THEME`
-- ----------------------------
DROP TABLE IF EXISTS `THEME`;
CREATE TABLE `THEME` (
  `theme_num` int(11) NOT NULL AUTO_INCREMENT,
  `theme_lib` varchar(20) NOT NULL,
  `theme_tarif` decimal(5,2) NOT NULL,
  PRIMARY KEY (`theme_num`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

-- ----------------------------
--  Records 
-- ----------------------------
INSERT INTO `ADHERENT` VALUES ('1','BOZZO','Raoul','24 rue du cirque','57000','Metz','bozzo.raoul@gmail.com','M.','33'), ('2','CREZINA','Albertine','37 avenue Caranaval','54000','Nancy','alb.crezina@free.fr','Mme','42'), ('3','DRAGON','Fragonard','7 rue du Feu éteint','75000','Paris','DragonFra@gmail.com','M.','61'), ('4','FICZERSKI','Karloff','2a rue des Tyrans','57000','Metz','karloff5577@bbox.fr','M.','12'), ('5','TALAOUI','Amina','','','','talaouinon@gmail.com','Mme','42'), ('6','RICANEUR','Eloise','98 impasse du Muguet','54000','Nancy','ricaneuresiole@bbox.fr','Mme','36'), ('7','LEBRAILLARD','Phil',NULL,NULL,NULL,'phil.lebraillard@gmail.com','M.','72');
INSERT INTO `ADHESION` VALUES ('2','5'), ('2','6'), ('2','7'), ('3','8'), ('3','9'), ('3','10'), ('3','11'), ('3','12'), ('3','13'), ('3','14'), ('3','15'), ('3','16'), ('4','1'), ('4','17'), ('5','6'), ('6','2'), ('6','4'), ('7','1'), ('7','3'), ('7','5'), ('7','6'), ('7','7');
INSERT INTO `CSP` VALUES ('1','Agriculteurs exploitants'), ('10','Agriculteurs exploitants'), ('11','Agriculteurs sur petite exploitation'), ('12','Agriculteurs sur moyenne exploitation'), ('13','Agriculteurs sur grande exploitation'), ('2','Artisans, commerçants et chefs d\'entreprise'), ('21','Artisans'), ('22','Commerçants et assimilés'), ('23','Chefs d\'entreprise de 10 salariés ou plus'), ('3','Cadres et professions intellectuelles supérieures'), ('31','Professions libérales et assimilés'), ('32','Cadres de la fonction publique, professions intellectuelles et  artistiques'), ('33','Cadres de la fonction publique'), ('34','Professeurs, professions scientifiques'), ('35','Professions de l\'information, des arts et des spectacles'), ('36','Cadres d\'entreprise'), ('37','Cadres administratifs et commerciaux d\'entreprise'), ('38','Ingénieurs et cadres techniques d\'entreprise'), ('4','Professions Intermédiaires'), ('41','Professions intermédiaires de l\'enseignement, de la santé, de la fonction publique et assimilés'), ('42','Professeurs des écoles, instituteurs et assimilés'), ('43','Professions intermédiaires de la santé et  du travail social'), ('44','Clergé, religieux'), ('45','Professions intermédiaires administratives de la fonction publique'), ('46','Professions intermédiaires administratives et commerciales des entreprises'), ('47','Techniciens'), ('48','Contremaîtres, agents de maîtrise'), ('5','Employés'), ('51','Employés de la fonction publique'), ('52','Employés civils et agents de service de la fonction publique'), ('53','Policiers et militaires'), ('54','Employés administratifs d\'entreprise'), ('55','Employés de commerce'), ('56','Personnels des services directs aux particuliers'), ('6','Ouvriers'), ('61','Ouvriers qualifiés'), ('62','Ouvriers qualifiés de type industriel'), ('63','Ouvriers qualifiés de type artisanal'), ('64','Chauffeurs'), ('65','Ouvriers qualifiés de la manutention, du magasinage et du transport'), ('66','Ouvriers non qualifiés'), ('67','Ouvriers non qualifiés de type industriel'), ('68','Ouvriers non qualifiés de type artisanal'), ('69','Ouvriers agricoles'), ('7','Retraités'), ('71','Anciens agriculteurs exploitants'), ('72','Anciens artisans, commerçants, chefs d\'entreprise'), ('73','Anciens cadres et professions intermédiaires'), ('74','Anciens cadres'), ('75','Anciennes professions intermédiaires'), ('76','Anciens employés et ouvriers'), ('77','Anciens employés'), ('78','Anciens ouvriers'), ('8','Autres personnes sans activité professionnelle'), ('81','Chômeurs n\'ayant jamais travaillé'), ('82','Inactifs divers (autres que retraités)'), ('83','Militaires du contingent'), ('84','Elèves, étudiants'), ('85','Personnes diverses sans activité  professionnelle de moins de 60 ans (sauf retraités)'), ('86','Personnes diverses sans activité professionnelle de 60 ans et plus (sauf retraités)');
INSERT INTO `THEME` VALUES ('1','manga','7.00'), ('2','comédie','4.00'), ('3','fantastique','9.00'), ('4','action','5.00'), ('5','science fiction','5.00'), ('6','bande dessinée','4.00'), ('7','humour','8.00'), ('8','aventure','9.00'), ('9','sport','6.00'), ('10','politique','11.00'), ('11','actualités','7.00'), ('12','série TV','5.00'), ('13','espionnage','8.00'), ('14','militaire','9.00'), ('15','guerre','7.00'), ('16','épouvante','5.00'), ('17','droit','12.00');
