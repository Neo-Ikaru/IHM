Lors de l'ex�cution de votre proc�dure stock�e, si vous avez un message ressemblant � "mix collation ..."

dans une requ�te avec une clause WHERE du style "nom colonne LIKE CONCAT('%',valeur,'%')" 
il faut ajouter � la ligne 
l'expression "COLLATE latin1_general_cs" pour rendre compatible les chaines de comparaison.